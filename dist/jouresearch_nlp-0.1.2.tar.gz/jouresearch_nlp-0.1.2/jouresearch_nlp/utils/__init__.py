import spacy

# To get model "python -m spacy download de_core_news_sm"
nlp = spacy.load("de_core_news_sm")

# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['jouresearch_nlp',
 'jouresearch_nlp.ner',
 'jouresearch_nlp.schemas',
 'jouresearch_nlp.topicmodelling',
 'jouresearch_nlp.utils',
 'jouresearch_nlp.wordcloud']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=8.4.0,<9.0.0',
 'bertopic>=0.9.4,<0.10.0',
 'multidict>=5.2.0,<6.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'spacy>=3.2.0,<4.0.0',
 'wordcloud>=1.8.1,<2.0.0']

setup_kwargs = {
    'name': 'jouresearch-nlp',
    'version': '0.1.6',
    'description': '',
    'long_description': None,
    'author': 'Felix Mertineit',
    'author_email': 'felix.mertineit@aureka.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

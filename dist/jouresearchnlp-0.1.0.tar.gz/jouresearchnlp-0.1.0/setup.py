# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['jouresearchnlp',
 'jouresearchnlp.ner',
 'jouresearchnlp.schemas',
 'jouresearchnlp.topicmodelling',
 'jouresearchnlp.utils',
 'jouresearchnlp.wordcloud']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=8.4.0,<9.0.0',
 'multidict>=5.2.0,<6.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'spacy>=3.2.0,<4.0.0',
 'wordcloud>=1.8.1,<2.0.0']

setup_kwargs = {
    'name': 'jouresearchnlp',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Felix Mertineit',
    'author_email': 'felix.mertineit@aureka.ai',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

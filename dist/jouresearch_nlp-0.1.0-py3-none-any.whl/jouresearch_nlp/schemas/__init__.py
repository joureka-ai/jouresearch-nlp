from .wordcloud import WordCloudS, Word
from .document import Document
